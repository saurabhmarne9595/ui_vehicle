import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'
import { FormsModule } from '@angular/forms'
import { Http, Headers, HttpModule } from '@angular/http'

import { AppComponent } from './app.component';
import { DashComponent } from './components/dash/dash.component';
import { InfluxService } from './services/influx.service'

const appRoutes = [
  { path: '', redirectTo: 'dash', pathMatch: 'full' },
  { path: 'dash', component: DashComponent }
]


@NgModule({
  declarations: [
    AppComponent,
    DashComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    RouterModule.forRoot(appRoutes),
    FormsModule,
    HttpModule
  ],
  providers: [InfluxService],
  bootstrap: [AppComponent]
})
export class AppModule { }
